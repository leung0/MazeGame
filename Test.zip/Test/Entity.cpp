/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Entity.cpp
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#include "Entity.h"

/***CONSTRUCTORS********************************************************/
//default constructor
Entity::Entity()
{

}

Entity::Entity(int row, int col, int sym)
{
    score = 0;
	this->row = row;
	this->col = col;
	this->sym = sym;
}

/***ACCESSOR METHODS**************************************************/
int Entity::getRow()
{
	return row;
}

int Entity::getCol()
{
	return col;
}

char Entity::getSym()
{
	return sym;
}

int Entity::getScore()
{
	return score;
}

/***MUTATOR METHODS**********************************************************/
void Entity::setPosition(int row, int col)
{
	this->row = row;
	this->col = col;
}

void Entity::setRow(int row)
{
	this->row = row;
}

void Entity::setCol(int col)
{
	this->col = col;
}

void Entity::setSym(char sym)
{
	this->sym = sym;
}

/***MOVEMENT*****************************************************************/
void Entity::moveUp(Map &map, char repl)
{
	if (map.isWalkable(row - 1, col))
	{
		map.place(row, col, repl);
		map.place(row - 1,col, sym);
		row--;
		score++;
	}
}

void Entity::moveDown(Map &map, char repl)
{
	if (map.isWalkable(row + 1, col))
	{
		map.place(row, col, repl);
		map.place(row + 1, col, sym);
		row++;
		score++;
	}
}

void Entity::moveLeft(Map &map, char repl)
{
	if (map.isWalkable(row, col - 1) )
	{
		map.place(row, col, repl);
		map.place(row, col - 1, sym);
		col--;
		score++;
	}
}

void Entity::moveRight(Map &map, char repl)
{
	if (map.isWalkable(row, col + 1))
	{
		map.place(row, col, repl);
		map.place(row, col + 1, sym);
		col++;
		score++;
	}
}
