/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Scores.cpp
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "Scores.h"
#include <iomanip>
#include <stdlib.h>

using namespace std;

//default constructor
Scores::Scores()
{
    best = 0;
    name = "";
    score = 0;
    lower = false;
}

//constructor creates score object and compares results to previous scores
Scores::Scores(int sc, char lvl)
{
    name = "";
    score = sc;
    level = lvl;
    best = 0;
    lower = false;
    compare();
}

//this method compares score with previous high score
void Scores::compare()
{
    get_highscore();
    if (score < best)		               // If recent score is better (less) than the highscore on file
    {
        ofstream out;                      // Makes an output file stream named "out" using "records"
        if(level == 'e')                   // is also overwrites the contents of "records"
            out.open("recordsE.txt");
        else if(level == 'm')
            out.open("recordsM.txt");
        else
            out.open("recordsD.txt");

        set_name();                         // Prompts user to type their name
        out << score << "\n" << name;	    // We write the score onto the first line and the name onto the second line of "records"
        out.close();						// Close the output file stream
        lower = true;
    }
}

//retrieves the highscore from the "records.txt" file
void Scores::get_highscore()
{
    ifstream in;                            // Make an input file stream named "in"
    if(level == 'e')
        in.open("recordsE.txt");            //opens "records" file to extract highscore data
    if(level == 'm')
        in.open("recordsM.txt");
    if(level == 'd')
        in.open("recordsD.txt");

    string bestStr = "";				    // Best score (taken from records file)
    getline(in, bestStr);	        		// Gets "bestStr" as a string from "records"
    istringstream ( bestStr ) >> best;      // Converts "bestStr" into "best" as an int

    getline(in, bestStr);
    bestName = bestStr;

    in.close();							        // Close the input file stream
}

//prints congratulations menu
void Scores::print()
{
    system("clear");
    int x = 30 + (kb.getWidth() - 30) / 2; //sets center from terminal width
    int y = (kb.getHeight() - 9) / 2; //sets center from terminal height
    for (int i = 0; i < y; i++)
        cout << '\n';

    cout << setw(x) << "******************************\n";
    cout << setw(x) << "*      CONGRATULATIONS!      *\n";
    cout << setw(x) << "* You have set a new record! *\n";
    cout << setw(x) << "*   Type in your initials!   *\n";
    cout << setw(x) << "*                            *\n";
    cout << setw(x - 18) << "*            " << BOLD << RED << setw(3) << name << WHITE << RESET << "             *\n";
    cout << setw(x) << "*                            *\n";
    cout << setw(x) << "*   Press ENTER to continue  *\n";
    cout << setw(x) << "******************************\n";
}

// Prompts the user to write their initials
void Scores::set_name()
{
    print();

    // Prompt user to input their initials
    char c;
    for (int i = 0; i < 3; i++)
    {
        c = kb.getch();
        if (c > 96 && c < 123)	// If character is lowercase
        {
            c = c - 32;			// Make it capital
        }
        if (c == BACKSPACE && i > 0) //deletes last letter typed
        {
            i--;
            name.erase(i, name.size() - i);
            print();
            i--;
        }
        else if (c == '\n') //submits initials
        {
            break;
        }
        else if (c > 64 && c < 91) //add letter to initials
        {
            name += c;
            print();
        }
        else //disregards any other input
            i--;
        if (i == 2)
        {
            while (true)
            {
                c = kb.getch();
                if (c == BACKSPACE)
                {
                    name.erase(i, name.size() - i);
                    print();
                    i--;
                    break;
                }
                if (c == '\n')
                    break;
            }
        }
    }
}

