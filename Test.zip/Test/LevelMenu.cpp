/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: LevelMenu.cpp
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "LevelMenu.h"
#include "Keyboard.h"

#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

//default constructor
LevelMenu::LevelMenu()
{
	option = 1;
	numOfOptions = 4;
}

//prints Level Menu depending on where option selector is located
void LevelMenu::Build()
{
    int x = 22 + (kb.getWidth() - 22) / 2; //sets center from terminal width
    int y = (kb.getHeight() - 9) / 2; //sets center from terminal height
    for (int i = 0; i < y; i++)
        cout << '\n';

	cout << setw(x) << "**********************\n";
	cout << setw(x) << "*    SELECT LEVEL    *\n";
	cout << setw(x) << "*                    *\n";
	if (option == 1)
		cout << setw(x) << "*  >  Easy           *\n";
	else
		cout << setw(x) << "*     Easy           *\n";
	if (option == 2)
		cout << setw(x) << "*  >  Medium         *\n";
	else
		cout << setw(x) << "*     Medium         *\n";
    if (option == 3)
		cout << setw(x) << "*  >  Difficult      *\n";
	else
		cout << setw(x) << "*     Difficult      *\n";
    if (option == 4)
		cout << setw(x) << "*  >  Back           *\n";
	else
		cout << setw(x) << "*     Back           *\n";
    cout << setw(x) << "*                    *\n";
	cout << setw(x) << "**********************\n";
}

//updates the Pause Menu after each movement and after clearing the terminal
void LevelMenu::Update()
{
    system("clear"); //clears the terminal
	Build();

}

//goes through the menu and returns an integer pertaining to a certain option of the program
int LevelMenu::Selection()
{
    option = 1; //sets default value for menu
    Keyboard kb; //creates keyboard instance
    Update(); //builds menu for the first time
    char c;

	while (true)
	{
        c = kb.getch(); //registers keyboard key pressed
		if (c == UP_ARROW) //up arrow key action
		{
			if (option == 1)
                option = numOfOptions;
            else
                option--;
            Update();
            continue;
		}
		if (c == DOWN_ARROW) //down arrow key action
		{
			if (option == numOfOptions)
                option = 1;
            else
                option++;
            Update();
            continue;
		}
		if (c == '\n') //return key
            break;
	}

    if (option == 4) //option 4 is the BACK option
        return 100;
    else
        return option + 1; //returns LEVEL difficulty selected
}

