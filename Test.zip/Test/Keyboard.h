/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Keyboard.h
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#ifndef KEYBOARD_H
#define KEYBOARD_H

#define UP_ARROW 0x41
#define DOWN_ARROW 0x42
#define RIGHT_ARROW 0x43
#define LEFT_ARROW 0x44
#define BACKSPACE 0x7f
#define ESC 0x1b

#define WHITE   "\033[37m"      /* White */
#define BLUE    "\033[34m"      /* Blue */
#define GREEN   "\033[32m"      /* Green */
#define RED     "\033[31m"      /* Red */
#define BLACK   "\033[30m"      /* Black */
#define RESET   "\033[0m"       /* Reset */
#define BOLD    "\033[1m"       /* Bold */
#define INVERT  "\033[7m"       /* Invert */

class Keyboard
{
    private:
        int width;
        int height;

    public:
        Keyboard();

        void changemode(int dir); //needed for kbhit //changemode(1) <---- needed before kbhit to clear buffer
        int kbhit(); //verifies keyboard is being pressed
        int getch(); //gets char without user having to press enter

        int getWidth();
        int getHeight();
};

#endif // KEYBOARD_H
