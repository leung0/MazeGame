/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Render.cpp
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#include "Render.h"
#include "Keyboard.h"
#include <iomanip>

//Default constructor
Render::Render()
{

}

//Constructor that sets map as this map
Render::Render(Map &map)
{
	this->map = map;
}

//Sets map as a new map if new map is selected
void Render::import(Map &map)
{
	this->map = map;
}

//Clears the terminal and reprints the map and new position of entity. Also displays current number of moves
void Render::update(int score, Map &m)
{
    system("clear");

    int x = m.getColumnSize() + (kb.getWidth() - m.getColumnSize()) / 2; //sets center from terminal width
    int x1 = 22 + (kb.getWidth() - 22) / 2; //sets center from terminal width
    int x2 = 18 + (kb.getWidth() - 18) / 2; //sets center from terminal width
    int y = (kb.getHeight() - m.getRowSize() - 2) / 2; //sets center from terminal height
    for (int i = 0; i < y; i++)
        cout << '\n';

	cout << setw(x1) << "Press E for Pause Menu" << endl;
	for(int i=0; i<m.getRowSize(); i++)
	{
        cout << setw(x - m.getColumnSize()) << " ";
		for(int j=0; j<m.getColumnSize(); j++)
		{
            if(m.getTile(i, j) == 'x' || m.getTile(i, j) == '!')
                cout << BOLD << RED;
            if(m.getTile(i, j) == '@')
                cout << BOLD << BLUE;
			cout << m.getTile(i, j);
			if(m.getTile(i, j) == 'x' || m.getTile(i, j) == '@' || m.getTile(i, j) == '!')
                cout << WHITE << RESET;
		}
		cout << endl;
	}

	cout << setw(x2 - 2) << "Number of Moves: " << score << endl;
}
