/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: StartMenu.cpp
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "StartMenu.h"
#include "LevelMenu.h"

#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;


//default constructor
StartMenu::StartMenu()
{
	option = 1;
	numOfOptions = 3;
}

//prints Start Menu depending on where option selector is located
void StartMenu::Build()
{
    int x = 22 + (kb.getWidth() - 22) / 2; //sets center from terminal width
    int y = (kb.getHeight() - 8) / 2; //sets center from terminal height
    for (int i = 0; i < y; i++)
        cout << '\n';

	cout << setw(x) << "**********************\n";
	cout << setw(x) << "*     START MENU     *\n";
	cout << setw(x) << "*                    *\n";
	if (option == 1)
		cout << setw(x) << "*  >  New Game       *\n";
	else
		cout << setw(x) << "*     New Game       *\n";
    if (option == 2)
        cout << setw(x) << "*  >  Help           *\n";
    else
        cout << setw(x) << "*     Help           *\n";
	if (option == 3)
		cout << setw(x) << "*  >  Exit           *\n";
	else
		cout << setw(x) << "*     Exit           *\n";
	cout << setw(x) << "*                    *\n";
	cout << setw(x) << "**********************\n";
}

void StartMenu::PrintHelp()
{
    system("clear"); // clears the terminal

    int x = 37 + (kb.getWidth() - 37) / 2; //sets center from terminal width
    int y = (kb.getHeight() - 23) / 2; //sets center from terminal height
    for (int i = 0; i < y; i++)
        cout << '\n';

    cout << setw(x) << "*************************************\n";
    cout << setw(x) << "*       WELCOME TO CRAZE MAZE!      *\n";
    cout << setw(x) << "*                                   *\n";
    cout << setw(x) << "* The objective of this game is to  *\n";
    cout << setw(x - 27) << "* take Mr.\"" << BOLD << BLUE << "@" << WHITE << RESET << "\" to the end goal which *\n";
    cout << setw(x - 12) << "* which is symbolized by \"" << BOLD << RED << "!" << WHITE << RESET << "\".       *\n";
    cout << setw(x) << "*                                   *\n";
    cout << setw(x) << "* Use your arrow keys to navigate   *\n";
    cout << setw(x) << "* the intricate paths of the craze  *\n";
    cout << setw(x) << "* maze!                             *\n";
    cout << setw(x) << "*                                   *\n";
    cout << setw(x) << "* And don't forget to press 'E' for *\n";
    cout << setw(x) << "* the pause menu! At this point of  *\n";
    cout << setw(x) << "* the game you can select to solve  *\n";
    cout << setw(x - 26) << "* the maze. " << BOLD << RED << "X" << WHITE << RESET << "'s will mark the       *\n";
    cout << setw(x) << "* shortest path possible.           *\n";
    cout << setw(x) << "*                                   *\n";
    cout << setw(x) << "* Make your way through the path    *\n";
    cout << setw(x) << "* and you could be the next Craze   *\n";
    cout << setw(x) << "* Maze Champion!!                   *\n";
    cout << setw(x) << "*                                   *\n";
    cout << setw(x) << "*      Press ENTER to continue      *\n";
    cout << setw(x) << "*************************************\n";

    char c = kb.getch(); //wait's until user presses ENTER before leaving the help menu
    while (c != '\n')
    {
        c = kb.getch();
    }
}

//updates the Start Menu after each movement and after clearing the terminal
void StartMenu::Update()
{
   system("clear"); //clears the terminal
   Build();
}

//goes through the menu and returns an integer pertaining to a certain option of the program
int StartMenu::Selection()
{
    option = 1; //sets default value for menu
    LevelMenu level; //creates level menu
    Update(); //builds menu for the first time
    char c;

	while (true) //loop moves through menu items and returns a selection
	{
        c = kb.getch(); //registers keyboard key pressed
		if (c == UP_ARROW) //up arrow key action
		{
			if (option == 1)
                option = numOfOptions;
            else
                option--;
            Update();
            continue;
		}
		if (c == DOWN_ARROW) //down arrow key
		{
			if (option == numOfOptions)
                option = 1;
            else
                option++;
            Update();
            continue;
		}
		if (c == '\n') //return key
            break;
	}

    if (option == 1) //if option 1 is selected the Levels Menu is opened
	{
        option = level.Selection();
        if (option == 100) //if option 100 is selected the BACK option was selected and the Start Menu is called
        {
            option = 1;
            Selection();
        }
	}
	else if (option == 2) //if option 2 is selected the Help Menu is printed
    {
        PrintHelp();
        option = 1;
        Selection();
    }
	else
       option = 0; //this is the EXIT option which ends the program

	return option; //returns LEVEL or EXIT option to main.cpp
}

