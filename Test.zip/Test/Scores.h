/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Scores.h
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#ifndef SCORES_H
#define SCORES_H

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include "Keyboard.h"

using namespace std;

class Scores
{
private:                                 // FOR FILES CALLING IT //
    void compare();          /////////////////////////////////////////////////////////////////////
    void get_highscore();    // - scores.lower() returns a boolean. If (scores.lower == true)   //
    void set_name();         // then we can make it a highscore.					            //
    void print();            // - scores.name() returns the string of the name of the		    //
    Keyboard kb;             // highscorer. 												    //
    char level;              // - scores.best() returns an int of the highscore on file		    //
                             /////////////////////////////////////////////////////////////////////
public:
    Scores();
    Scores(int score, char lvl);
    string name;
    string bestName;
    int best;
    int score;
    bool lower;
};

#endif
