/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Player.cpp
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#include "Player.h"
#include "Keyboard.h"

//reference http://stackoverflow.com/questions/120876/c-superclass-constructor-calling-rules
//for superconstructors
Player::Player()
	: Entity()
{

}

Player::Player(Map &map)
	: Entity(1, 1, '@')
{
	map.place(1,1,'@');
}

char Player::move(Map &map)
{
	char key = getKeyPress();

	switch (key)
	{
		case 'u': moveUp(map, ' ');
			break;

		case 'd': moveDown(map, ' ');
			break;

		case 'l': moveLeft(map, ' ');
			break;

		case 'r': moveRight(map, ' ');
			break;
		case 'e':
			return key;
			break;
	}
	return key;
}

char getKeyPress()
{
	char k;
    Keyboard kb = Keyboard();
	k = kb.getch();
	if (k == UP_ARROW) //up arrow
	{
		k = 'u';
	}
	else if (k == LEFT_ARROW) //left arrow
	{
		k = 'l';
	}
	else if (k == RIGHT_ARROW) //right
	{
		k = 'r';
	}
	else if (k == DOWN_ARROW) //down
	{
		k = 'd';
	}

	return k;
}
