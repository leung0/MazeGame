/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: StartMenu.h
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "Keyboard.h"

#ifndef STARTMENU_H
#define STARTMENU_H

class StartMenu
{
private:
	int option;
	int numOfOptions;
	void PrintHelp();
    void Build();
	void Update();
	Keyboard kb;

public:
	StartMenu();
	int Selection();
};

#endif
