/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Keyboard.cpp
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "Keyboard.h"
#include <stdio.h> //needed for getch & length and height
#include <unistd.h> //needed for getch
#include <termios.h> //Linux specific lib... contains definitions for terminal
#include <sys/types.h> //needed for getch
#include <sys/time.h> //needed for getch
#include <sys/ioctl.h> //needed for length and height
using namespace std;

Keyboard::Keyboard()
{

}

int Keyboard::getWidth() //returns the width of the terminal
{
    struct winsize w;
    ioctl(0, TIOCGWINSZ, &w);
    width = w.ws_col; //determines the width of the terminal
    return this->width;
}

int Keyboard::getHeight() //returns the height of the terminal
{
    struct winsize w;
    ioctl(0, TIOCGWINSZ, &w);
    height = w.ws_row; //determines the height of the terminal
    return this->height;
}

void changemode(int dir)
{
//changemode(1) <---- needed before kbhit to clear buffer
    static struct termios oldt;
    static struct termios newt;

    if ( dir == 1 )
    {
            tcgetattr( STDIN_FILENO, &oldt);
            newt = oldt;
            newt.c_lflag &= ~( ICANON | ECHO );
            tcsetattr( STDIN_FILENO, TCSANOW, &newt);
    }
    else
    {
            tcsetattr( STDIN_FILENO, TCSANOW, &oldt);
    }
}

int kbhit (void) //verifies if a key board is pressed
{
    struct timeval tv;
    fd_set rdfs;

    tv.tv_sec = 0;
    tv.tv_usec = 0;

    FD_ZERO(&rdfs);
    FD_SET (STDIN_FILENO, &rdfs);

    select(STDIN_FILENO+1, &rdfs, NULL, NULL, &tv);
    return FD_ISSET(STDIN_FILENO, &rdfs);
}

int Keyboard::getch()	//customized get char method that takes inputs w/o pressing enter
{
    int ch;
    struct termios oldt;
    struct termios newt;
    tcgetattr(STDIN_FILENO, &oldt);     //store old settings
    newt = oldt;                        // copy old settings to new settings
    newt.c_lflag &= ~(ICANON | ECHO);   // make one change to old settings in new settings
    tcsetattr(STDIN_FILENO, TCSANOW, &newt); //apply the new settings immediatly
    ch = getchar();                     // standard getchar call
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt); //reapply the old settings
    return ch;                          //return received char
}

