/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Player.h
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#ifndef PLAYER_H
#define PLAYER_H

#include "Entity.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>

class Player : public Entity
{
public:
	Player();
	Player(Map &map);
	char move(Map &map);
};

char getKeyPress();

#endif
