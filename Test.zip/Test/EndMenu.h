/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: EndMenu.h
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "Keyboard.h"
#include "Scores.h"

#ifndef ENDMENU_H
#define ENDMENU_H

class EndMenu
{
private:
	int option;
	int numOfOptions;
	int moves;
	char level;
    void Build();
	void Update();
	Keyboard kb;
	Scores sc;

public:
	EndMenu();
	int Selection(int moves, char lvl);
};

#endif
