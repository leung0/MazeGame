/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: PauseMenu.cpp
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "PauseMenu.h"
#include "LevelMenu.h"
#include "Keyboard.h"

#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

//default constructor
PauseMenu::PauseMenu()
{
	option = 1;
	numOfOptions = 4;
}

//prints Pause Menu depending on where option selector is located
void PauseMenu::Build()
{
    int x = 22 + (kb.getWidth() - 22) / 2; //sets center from terminal width
    int y = (kb.getHeight() - 9) / 2; //sets center from terminal height
    for (int i = 0; i < y; i++)
        cout << '\n';

	cout << setw(x) << "**********************\n";
	cout << setw(x) << "*     PAUSE MENU     *\n";
	cout << setw(x) << "*                    *\n";
	if (option == 1)
		cout << setw(x) << "*  >  Resume Game    *\n";
	else
		cout << setw(x) << "*     Resume Game    *\n";
	if (option == 2)
		cout << setw(x) << "*  >  New Game       *\n";
	else
		cout << setw(x) << "*     New Game       *\n";
    if (option == 3)
		cout << setw(x) << "*  >  Solve          *\n";
	else
		cout << setw(x) << "*     Solve          *\n";
    if (option == 4)
		cout << setw(x) << "*  >  Exit           *\n";
	else
		cout << setw(x) << "*     Exit           *\n";
	cout << setw(x) << "*                    *\n";
	cout << setw(x) << "**********************\n";
}

//updates the Pause Menu after each movement and after clearing the terminal
void PauseMenu::Update()
{
    system("clear"); //clears the terminal
    Build();
}

//goes through the menu and returns an integer pertaining to a certain option of the program
int PauseMenu::Selection()
{
    option = 1; //sets default value for menu
    LevelMenu level; //creates level menu
    Keyboard kb; //creates keyboard instance
    Update(); //builds menu for the first time
    char c;

	while (true)
	{
        c = kb.getch(); //registers keyboard key pressed
		if (c == UP_ARROW) //up arrow key action
		{
			if (option == 1)
                option = numOfOptions;
            else
                option--;
            Update();
            continue;
		}
		if (c == DOWN_ARROW) //down arrow key action
		{
			if (option == numOfOptions)
                option = 1;
            else
                option++;
            Update();
            continue;
		}
		if (c == '\n') //return key
            break;
	}

    if (option == 1) //if option 1 is selected the RESUME GAME is returned
        option = 6;
	else if (option == 2) //if option 2 is selected the Levels Menu is opened
	{
        option = level.Selection();
        if (option == 100) //if option 100 is selected the BACK option was selected and the Pause Menu is called
        {
            option = 1;
            Selection();
        }
	}
	else if (option == 3) //if option 3 is selected the SOLVE option is returned
	{
        option = 7;
	}

	else
        option = 0; //this is the EXIT option which ends the program

	return option; //returns RESUME GAME, SOLVE, LEVEL or EXIT option to main.cpp
}

