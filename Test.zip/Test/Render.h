/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Render.h
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#ifndef RENDER_H_
#define RENDER_H_

#include <iostream>
#include "Map.h"
#include "Keyboard.h"
#include <cstdlib>

using namespace std;

//Displays the map in terminal
class Render
{
public:
	Render();
	Render(Map &map);
	void import(Map &map);
	void update(int score, Map &m);
private:
	Map map;
	Keyboard kb;
};

#endif /* RENDER_H_ */
