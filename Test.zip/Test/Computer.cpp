/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Computer.cpp
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#include "Computer.h"

Point::Point(int row, int col)
{
	this->row = row;
	this->col = col;
}
int Point::getRow()
{
	return row;
}
int Point::getCol()
{
	return col;
}

//Method: Node
//return: void
//purpose: the default constructor that sets all
//		   values to zero
Node::Node()
{
	parent = NULL;
	close = false;
	open = false;

	row = col = 0;

	f = g = h = 0;
}

//Method: Node
//return: void
//purpose: the default constructor that sets all
//		   values to zero or their respective values
Node::Node(int row, int col)
{
	parent = NULL;
	close = false;
	open = false;

	f = g = h = 0;
	this->row = row;
	this->col = col;
}

//Method: Node
//return: void
//purpose: the default constructor that sets all
//		   values to zero or their respective values
Node::Node(int row, int col, bool possible)
{
	parent = NULL;
	close = false;
	open = false;

	f = g = h = 0;
	this->possible = possible;
	this->row = row;
	this->col = col;

}

//Method: getRow
//return: int
//purpose: returns the value of the row that the node
//			is currently at
int Node::getRow()
{
	return row;
}

//Method: getCol
//Return: int
//purpose: returns the value of the column that the
//			node is currently at

int Node::getCol()
{
	return col;
}

//method: getParent
//return: Node*
//purpose: shows the program the tile that the computer
//			would have came from when it went to the current
//			one
Node* Node::getParent()
{
	return parent;
}

//Method: getOpen
//return: bool
//purpose: to tell if this node is in the open list
//			meaning that it is a node that will be apart
//			of the final solution
bool Node::getOpen()
{
	return open;
}

//Method: getClose
//return: bool
//purpose: to tell if this node is apart of the closed
//			list, meaning that it was tested and wont
//			be used as a part of the final solution
bool Node::getClose()
{
	return close;
}

//method: getG
//return:int
//purpose: to return the value of g, or the amount of
//			steps taken so far
int Node::getG()
{
	return g;
}

//method:getH
//return: int
//purposeL to return the value of g, the amount of steps
//			expected left
int Node::getH()
{
	return h;
}

//method: getF
//return: int
//purpose: to return f, or the predicted travel
int Node::getF()
{
	return f;
}

//method: hasParent
//return: bool
//purpose: returns true if there is a parent
bool Node::hasParent()
{
	return (parent != NULL);
}

void Node::setPos(int row, int col)
{
	this->row = row;
	this->col = col;
}

void Node::setRow(int row)
{
	this->row = row;
}

void Node::setCol(int col)
{
	this->col = col;
}

void Node::setParent(Node *n)
{
	parent = n;
}

void Node::setOpen(bool open)
{
	this->open = open;
}

void Node::setClose(bool close)
{
	this->close = close;
}

int Node::calcGScore(Node* p)
{
	if (p != NULL)
	{
		int temp = p->g;
		temp += ((row == p->row || col == p->col) ? 10 : 0);
		return temp;
	}
	return 0;
}

int Node::calcHScore(Node* end)
{
	int y = abs((end->getRow()) - row) * 10;
	int x = abs((end->getCol()) - col) * 10;
	return x + y;
}

int Node::calcFScore(Node* end)
{
	g = calcGScore(parent);
	h = calcHScore(end);
	f = g + h;
	return f;
}

//superconstructor
_Astar::_Astar()
{

}

_Astar::_Astar(Map &map)
{
	m = map;
}

std::vector<Point*>  _Astar::getPath(int srow, int scol, int erow, int ecol, int bSize)
{
	std::vector<Point*> f_path;

	//used to hold the path and the points that we
	//won't use
	std::list<Node*> open;

	//used to hold the path and the points that we
	//will use
	std::list<Node*> closed;

	//used to traverse and build lists
	Node* cur;
	Node* child;
	std::list<Node*>::iterator i;

	int n = 0;

	Node* start = new Node(srow, scol);
	Node* end = new Node(erow, ecol);

	//open list is the place to start calculating
	open.push_back(start);
	cur = start;
	start->setOpen(true);

	//if this is the starting position or we haven't found the end point
	while (n == 0 || (cur != end && n < (bSize * bSize * bSize)))
	{
		//finding the point with the smallest F
		//then make it the current position
		for (i = open.begin(); i != open.end(); ++i)
		{
			if ((i == open.begin() || (*i)->calcFScore(end) <= cur->calcFScore(end)))
				cur = *i;
		}

		//if we reach the end stop
		if (cur->getCol() == end->getCol() && cur->getRow() == end->getRow())
			break;

		//adds the best option to the final path
		open.remove(cur);
		cur->setOpen(false);

		closed.push_back(cur);
		cur->setClose(true);
		bool flag = false;

		//find all the possible points to go to next
		for (int row = -1; row < 2; row++)//3x3 movement
		{
			for (int col = -1; col < 2; col++)
			{
				flag = false;
				//if the movement isnt a straight line don't bother
				if ((row != 0 && col != 0) || (row == 0 && col == 0))
					continue;

				child = new Node(cur->getRow() + row, cur->getCol() + col);

				//if the child has already been tested skip over it or in a unreachable point
				if (!m.isWalkable(child->getRow(), child->getCol()))
					continue;

				//if this has already been accessed
				if (child->getOpen())
				{
					continue;
				}

				for (i = open.begin(); i != open.end(); ++i)
				{
					if ((*i)->getRow() == child->getRow() && (*i)->getCol() == child->getCol())
						flag = true;
				}
				if (flag)
					continue;

				//adding the child to possible list
				open.push_back(child);
				child->setOpen(true);

				//set Parent to the current and calc f
				child->setParent(cur);
				child->calcFScore(end);

			}
		}

		//makes sure we don't run out of tiles to check
		n++;
	}

	while (cur->hasParent() && cur != start)
	{
		//adds the position to f_path
		f_path.push_back(new Point(cur->getRow(), cur->getCol()));
		cur = cur->getParent();
	}
	f_path.push_back(new Point(srow, scol));
	path = f_path;
	return f_path;
}

void _Astar::printPath()
{
	for (int i = path.size() - 1; i > 0; i--)
	{
		std::cout << "(" << path[i]->getRow() << "," << path[i]->getCol() << ")" << std::endl;
	}
}

Point* _Astar::getNextMove(int cur_row, int cur_col)
{
	for (int i = path.size() - 1; i > 0; i--)
	{
		if (path[i]->getRow() == cur_row && path[i]->getCol() == cur_col)
		{
			i--;
			//gets the point at the index after the current one
			return path[i];
		}
	}
	Point* pnt = new Point(-1,-1);
	//if for some reason it can't find the next move
	return pnt;
}

//superconstructor
Computer::Computer()
	: Entity()
{

}

Computer::Computer(Map &map)
	: Entity(1, 1, '@')
{
	m = map;
}

void Computer::move(Map &map, _Astar &a)
{
	int cur_row = this->getRow();
	int cur_col = this->getCol();

	Point* temp = a.getNextMove(cur_row, cur_col);

	int next_row = temp->getRow();
	int next_col = temp->getCol();

	int dif_row = next_row - cur_row;
	int dif_col = next_col - cur_col;
	if (dif_row == 1 && dif_col == 0)
	{
		//move down because next row is larger than cur cur
		moveDown(map, 'x');
	}
	else if (dif_row == -1 && dif_col == 0)
	{
		//move up
		moveUp(map, 'x');
	}
	else if (dif_row == 0 && dif_col == 1)
	{
		//move right
		moveRight(map,'x');
	}
	else if (dif_row == 0 && dif_col == -1)
	{
		//move left
		moveLeft(map, 'x');
	}
}
