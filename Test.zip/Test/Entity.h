/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Entity.h
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#ifndef ENTITY_H
#define ENTITY_H

#include"Map.h"

class Entity
{
public:
/***CONSTRUCTORS***/
	Entity();
	Entity(int row, int col, int sym);

/***ACCESSOR METHODS***/
	int getRow();
	int getCol();
	char getSym();
	int getScore();

/***MUTATOR METHODS***/
	void setPosition(int row, int col);
	void setRow(int row);
	void setCol(int col);
	void setSym(char sym);

/***MOVEMENT***/
	void moveUp(Map &map, char repl);
	void moveDown(Map &map, char repl);
	void moveLeft(Map &map, char repl);
	void moveRight(Map &map, char repl);

private:
	int row;
	int col;
	int score;
	char sym;

};

#endif
