/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: LevelMenu.h
**Date Created: 3/15/2015
**Date Last Modified: 4/10/2015
**Purpose:
**********************************/

#include "Keyboard.h"

#ifndef LEVELMENU_H
#define LEVELMENU_H

class LevelMenu
{
private:
	int option;
	int numOfOptions;
    void Build();
	void Update();
	Keyboard kb;

public:
	LevelMenu();
	int Selection();
};

#endif

