/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Computer.h
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#ifndef COMPUTER_H
#define COMPUTER_H

#include "Entity.h"
#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <cstdlib>
#include "stdio.h"

class Point
{
public:
	Point(int row, int col);
	int getRow();
	int getCol();

private:
	int col, row;
};



class Node
{
public:
	Node();
	Node(int row, int col);
	Node(int row, int col, bool possible);

	int* getPos();
	int getRow();
	int getCol();
	Node* getParent();
	bool getOpen();
	bool getClose();

	int getG();
	int getH();
	int getF();

	bool hasParent();

	void setPos(int row, int col);
	void setRow(int row);
	void setCol(int col);
	void setParent(Node *n);
	void setOpen(bool open);
	void setClose(bool close);

	int calcGScore(Node* parent);
	int calcHScore(Node* end);
	int calcFScore(Node* end);

private:
	bool close;
	bool open;
	bool possible;
	Node* parent;
	int f, g, h;
	int row, col;
};


class _Astar
{
public:
	_Astar();
	_Astar(Map &map);

	// this is the impplementation of the A* algorithm
	std::vector<Point*> getPath(int srow, int scol, int erow, int ecol, int bSize);

	void printPath();

	Point* getNextMove(int cur_row, int cur_col);

private:
	std::vector<Point*> path;
	Map m;
};

class Computer : public Entity
{
public:
	Computer();
	Computer(Map &map);

	void move(Map &map, _Astar &a);

private:
	Map m;
};

#endif
