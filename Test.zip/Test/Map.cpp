/**********************************
 **Project: MazeSolver
 **Project Leader: Bobbie Isaly
 **Project Members: Steven Remington, Olivia Leung
 **		Brad Lazar, Jose Bohorques
 **File Name: Map.cpp
 **Date Created: 3/15/2015
 **Date Last Modified: 3/15/2015
 **Purpose:
 **********************************/

#include "Map.h"

//default constructor
Map::Map()
{

}

Map::Map(std::string lvlName)
{
    colSize = 0;
    rowSize = 0;
    this->lvlName = "";
	this->lvlName += lvlName;
	build();
}

void Map::build()
{
    rowSize = 0;
    colSize = 0;
	std::ifstream inputFile(lvlName.c_str());
	std::string temp;

	while(getline(inputFile,temp))
	{
		for (int j = 0; j < temp.size() ; j++)
		{
            colSize = temp.size();
			map[rowSize][j] = temp[j];
		}
		rowSize++;
	}

}

int Map::getEndRow(){
	for (int i = 0; i < getRowSize(); i++)
	{
		for (int j = 0; j < getColumnSize(); j++)
		{
			if (map[i][j] == '!')
				return i;
		}
	}
}


int Map::getEndCol(){
	for (int i = 0; i < getRowSize(); i++)
	{
		for (int j = 0; j < getColumnSize(); j++)
		{
			if (map[i][j] == '!')
				return j;
		}
	}
}

int Map::getRowSize() { return rowSize; }

int Map::getColumnSize() { return colSize; }

void Map::place(int row, int col, char sym)
{
	map[row][col] = sym;
}

std::string Map::getLvlName()
{
	return lvlName;
}

char Map::getTile(int row, int col)
{
    return map[row][col];
}


bool Map::isWalkable(int row, int col)
{
	if (map[row][col] != '#')
		return true;
	return false;
}
