/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Driver.h
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/




#ifndef DRIVER_H
#define DRIVER_H

#include "unistd.h"

#include "Render.h"
#include "Map.h"

#include "Player.h"
#include "Computer.h"
#include "Entity.h"

#include "StartMenu.h"
#include "PauseMenu.h"
#include "EndMenu.h"

enum GameState
{
	RUNNING,
	WON,
	PAUSED,
	EXITING,
};

int runComputer(Map &m, int goalR, int goalC, int mSize);
int runEasy();
int runMedium();
int runDifficult();

#endif
