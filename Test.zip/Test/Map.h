/**********************************
**Project: MazeSolver
**Project Leader: Bobbie Isaly
**Project Members: Steven Remington, Olivia Leung
**		Brad Lazar, Jose Bohorques
**File Name: Map.h
**Date Created: 3/15/2015
**Date Last Modified: 3/15/2015
**Purpose:
**********************************/

#ifndef MAP_H
#define MAP_H

#include <string>
#include "stdio.h"
#include <fstream>
#include <iostream>
#include <string>

class Map
{
public:
	Map();
	Map(std::string lvlName);

	void build();
	void place(int row, int col, char sym);

	char getTile(int row, int col);
	int getEndRow();
	int getEndCol();

    int getRowSize();

    int getColumnSize();

	std::string getLvlName();

	bool isWalkable(int row, int col);

private:
	std::string lvlName;
	char map[50][50];
	int colSize;
	int rowSize;
};

#endif
