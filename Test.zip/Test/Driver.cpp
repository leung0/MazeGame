/**********************************
 *Project: MazeSolver
 *Project Leader: Bobbie Isaly
 *Project Members: Steven Remington, Olivia Leung
 *		Brad Lazar, Jose Bohorques
 *File Name: Driver.cpp
 *Date Created: 3/15/2015
 *Date Last Modified: 3/15/2015
 *Purpose:
 **********************************/
#include "Driver.h"

int state = RUNNING;
char lvl = 'e';
int main()
{
	StartMenu start = StartMenu();
	EndMenu finish = EndMenu();
    int sc = 0;

	do {
		switch(start.Selection())
		{
			case 2:
				sc = runEasy();
				lvl = 'e';
				break;
			case 3:
				sc = runMedium();
				lvl = 'm';
				break;
			case 4:
				sc = runDifficult();
				lvl = 'd';
				break;
			case 0:
				state = EXITING;
				break;
		}

		while (state == WON)
		{
			switch(finish.Selection(sc, lvl))
			{
				case 2:
					sc = runEasy();
					lvl = 'e';
					break;
				case 3:
					sc = runMedium();
					lvl = 'm';
					break;
				case 4:
					sc = runDifficult();
					lvl = 'd';
					break;
				case 0:
					state = EXITING;
					break;
			}
		}

	} while (state == RUNNING);

	return 0;
}

int runEasy()
{
    EndMenu finish = EndMenu();
    PauseMenu pm = PauseMenu();
	Map m = Map("levelEasy.txt");
	m.build();
	Render c = Render(m);
    int sc = 0;
    char test;
	int goalC = m.getEndCol();
	int goalR = m.getEndRow();

	Player p = Player(m);
	do{
        state = RUNNING;
		c.update(p.getScore(),m);
		char a = p.move(m);
		sc = p.getScore();
		if (a == 'e'||a == 'E')
		{
			state = PAUSED;
			switch(pm.Selection())
			{
				case 2:
					sc = runEasy();
					lvl = 'e';
					break;
				case 3:
					sc = runMedium();
					lvl = 'm';
					break;
				case 4:
					sc = runDifficult();
					lvl = 'd';
					break;
				case 6://resume
					state = RUNNING;
					break;
				case 7://solve
					sc = runComputer(m, 8,18,20);
					p = Player(m);
					test = p.move(m);
					if(test == 'u' || test == 'd' || test == 'l' || test == 'r')
                        sc = p.getScore();
					break;
				case 0:
					state = EXITING;
					break;
			}
		}
		if (goalC == p.getCol() && goalR == p.getRow())
			state = WON;
	} while (state == RUNNING);
	return sc;
}

int runMedium()
{
    EndMenu finish = EndMenu();
    Map m = Map("levelMedium.txt");
	m.build();
	Render c = Render(m);
    int sc = 0;
    char test;
	PauseMenu pm = PauseMenu();//27

    int goalC = m.getEndCol();
	int goalR = m.getEndRow();

	Player p = Player(m);
	do{
        state = RUNNING;

		c.update(p.getScore(),m);
		char a = p.move(m);
		sc = p.getScore();
		if (a == 'e'||a == 'E') //triggering the pause through ESC //figure out hexadecimal
		{
			state = PAUSED;
			switch(pm.Selection())
			{
				case 2:
					sc = runEasy();
					lvl = 'e';
					break;
				case 3:
					sc = runMedium();
					lvl = 'm';
					break;
				case 4:
					sc = runDifficult();
					lvl = 'd';
					break;
				case 6://resume
					state = RUNNING;
					break;
				case 7://solve
					sc = runComputer(m,18,18,20);
					p = Player(m);
					test = p.move(m);
					if(test == 'u' || test == 'd' || test == 'l' || test == 'r')
                        sc = p.getScore();
					break;
				case 0:
					state = EXITING;
					break;
			}

		}
		if (goalC == p.getCol() && goalR == p.getRow())
			state = WON;
	} while (state == RUNNING);
	return sc;
}

int runDifficult()
{
    EndMenu finish = EndMenu();
	Map m = Map("levelDifficult.txt");
	m.build();
	Render c = Render(m);
    int sc = 0;
	PauseMenu pm = PauseMenu();//27
    char test;
	int goalC = m.getEndCol();
	int goalR = m.getEndRow();

	Player p = Player(m);
	do{
        state = RUNNING;
        sc = p.getScore();
		c.update(p.getScore(),m);
		char a = p.move(m);
		if (a == 'e'||a == 'E') //triggering the pause through ESC //figure out hexadecimal
		{
			state = PAUSED;
			switch(pm.Selection())
			{
				case 2:
					sc = runEasy();
					lvl = 'e';
					break;
				case 3:
					sc = runMedium();
					lvl = 'm';
					break;
				case 4:
					sc = runDifficult();
					lvl = 'd';
					break;
				case 6://resume
					state = RUNNING;
					break;
				case 7://solve
					sc = runComputer(m,23,48,50);

                    p = Player(m);
					test = p.move(m);
					if(test == 'u' || test == 'd' || test == 'l' || test == 'r')
                        sc = p.getScore();
					break;
				case 0:
					state = EXITING;
					break;
			}
		}
		if (goalC == p.getCol() && goalR == p.getRow())
			state = WON;
	} while (state == RUNNING);
	return sc;
}

int runComputer(Map &m, int goalR, int goalC, int mSize)
{
    m.build();
    Render c = Render(m);
    int sc = 0;

    state = RUNNING;

	_Astar a = _Astar(m);
	a.getPath(1,1,goalR, goalC,mSize);


	Computer cmp = Computer(m);

	do{

        cmp.move(m,a);
		c.update(cmp.getScore(),m);
        usleep(100000);

		if (goalC == cmp.getCol() && goalR == cmp.getRow())
			state = WON;
	} while (state == RUNNING);
	state=RUNNING;
    return sc;
}
